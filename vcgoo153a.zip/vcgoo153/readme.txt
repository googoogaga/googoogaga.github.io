vcgoo153a
=========
This is a port of Goo v0.153 to work using the Microsoft
Visual Studio C++ compiler.

Included in this version is:

  a) Thread support
  b) Dynamic compilation support
     
First you require the original Goo 153 distribution from
http://www.googoogaga.org. Once you have unpacked that distribution,
copy the contents of this archive over that install. This archive only
contains the changed files and any additional files needed.

Once this is done, make sure your C++ environment variables are set
(vcvars32.bat or corvars.bat).

To create a Win32 executable, run win32-vc/build.bat.This will create
'goovc.exe' in the win32-vc directory which should run correctly. Most
of Goo works including dynamic compilation, thread and locking
support.

Please report bugs to the maintainer of this archive, Chris Double
(chris.double@double.co.nz).

Note that you can use Visual C++ 6.0 or the free C compiler that ships
with the Microsoft .NET Framework SDK. The only disadvantage with the
latter is you don't get compiler optimisations so Goo runs slower.

Notes
=====
To turn dynamic compilation on use ',g2c-eval'. To turn it off, use
',ast-eval'. It defaults to dynamic compilation on. You may wish to
turn it off as that's the more stable, tested option.

You'll need a '\tmp' directory on the same drive as the Goo executable
for the dynamic compilation to work.

Chris Double
04 February 2003
http://www.double.co.nz
http://radio.weblogs.com/0102385
chris.double@double.co.nz
